# Vulnerability Title

> Vulnerability description - reference

## Summary

- [Tools](#tools)
* [Something](#something)
  * [Subentry 1](#sub1)
  * [Subentry 2](#sub2)

## Tools

- [Tool 1](https://example.com)
- [Tool 2](https://example.com)

## Something

Quick explanation

```powershell
Exploit
```

## References

- [Blog title - Author, Date](https://example.com)